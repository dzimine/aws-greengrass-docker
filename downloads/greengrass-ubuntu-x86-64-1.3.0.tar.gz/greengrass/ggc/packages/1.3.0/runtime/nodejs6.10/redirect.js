/*
 * Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

const util = require('util');
const greengrassCommon = require('aws-greengrass-common-js');
const logging = require('aws-greengrass-common-js').logging;

const envVars = greengrassCommon.envVars;
const functionArn = envVars.MY_FUNCTION_ARN;

// Setup our lambda logger which logges to user lambda log
const arnFields = new greengrassCommon.FunctionArnFields(functionArn);
const lambdaLogGroupName = util.format('/Lambda/%s/%s/%s', arnFields.region, arnFields.accountId, arnFields.name);
const lambdaLogger = new logging.LocalWatchLogger(lambdaLogGroupName, 'fromNodeAppender');

function stdredirect() {
    process.stdout.write = function stdoutWrite(data) {
        lambdaLogger.info(data);
    };

    process.stderr.write = function stderrWrite(data) {
        lambdaLogger.error(data);
    };
}

exports.stdredirect = stdredirect;
exports.lambdaLogger = lambdaLogger;
